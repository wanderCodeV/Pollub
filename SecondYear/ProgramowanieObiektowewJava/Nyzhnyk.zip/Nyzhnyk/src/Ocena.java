public enum Ocena {
    NIEDOSTATECZNY,
    DOSTATECZNY,
    DOSTATECZNY_PLUS,
    DOBRY,
    DOBRY_PLUS,
    BARDZO_DOBRY
}
